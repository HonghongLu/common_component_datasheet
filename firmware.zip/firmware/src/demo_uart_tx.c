#include <stdio.h>
#include <string.h>

#include "bk2461.h"
#include "driver_gpio.h"
#include "driver_pwm.h"
#include "driver_saradc.h"

#include "driver_rf.h"
#include "driver_uart.h"



const uint8 tblRfChn[]={100,100,100,100};
///*
void StartRfTX(uint8 chn,char*buf,uint8 len){
    RF_Set_Chn(chn);
    //delay(50);
    SwitchToTxMode();
    FLUSH_TX;
    FLUSH_RX;
    while(TRX_FIFO_STATUS & B_FIFO_TX_FULL);    // Wait for TX_FIFO empty
    W_TX_PAYLOAD(buf, len);
}
//*/
//uint8 SendBuf[10];
//uint8 rxBuf[10];
#define  UART_DATA_LEN          32
#define  UART_COMMAND_LEN       8
#define  UART_DATA_START        0x55

xdata uint8 uart_data_receive[UART_DATA_LEN];
xdata uint8 rx_wrptr = 0;
xdata uint8 rx_rdptr = 0;
xdata uint8 uart_command_len = 0;
xdata uint8 uart_command[UART_COMMAND_LEN];
xdata uint8 tx_data;
void rcvUartCmd(void)
{
    if(RI)
    {
        RI = 0;
        uart_data_receive[rx_wrptr++] = SBUF0;
        if(rx_wrptr >= UART_DATA_LEN)
            rx_wrptr = 0;
    }
}
uint8 anaUartCmd(){
    uart_command_len = (rx_wrptr - rx_rdptr + UART_DATA_LEN) % UART_DATA_LEN;
    if(uart_command_len < UART_COMMAND_LEN)
        return 0;

    memcpy(uart_command, &uart_data_receive[rx_rdptr], UART_COMMAND_LEN);
    rx_rdptr += UART_COMMAND_LEN;
    if(rx_rdptr >= UART_DATA_LEN)
        rx_rdptr = 0;
    return 1;
}
uint8 SendBuf[5];

void test_rfTX (void)
{
    uint8 i;
    int cnt_send = 0;
    uint8 current_pipe;
    uint8 cnt_loop_pipes = 0;

	uint8 Val = 0;
    uint8 chn=0;
    ChangeTxPipe(2);
    RF_SetupInterrupt(B_IRQ_MAX_RT|B_IRQ_TX_DS|B_IRQ_RX_DR);
    memset(SendBuf,0,5);


	do
	{
        rcvUartCmd();
        if(anaUartCmd()>0){
            for(i=0;i<8;i++){
                PRINT("%.2bx ",uart_command[i]);
                }
            PRINT("\r\n");
            if((uart_command[0]==0x01)||(uart_command[1]==0xa1)){
                SendBuf[0]++;
                //SendBuf[1]=uart_command[2];
                memcpy(&SendBuf[1],&uart_command[2],4);
                StartRfTX(tblRfChn[chn], SendBuf, 5);
                Delay_ms(1);
                while(1){
                    if(TRX_IRQ_STATUS & B_IRQ_TX_DS)
                    {
                        //PRINT("IRQ_TX_DS\n");
                        TRX_IRQ_STATUS = B_IRQ_TX_DS;
                        break;
                    }

                    if(TRX_IRQ_STATUS & B_IRQ_MAX_RT)
                    {
                        //PRINT("IRQ_MAX_RT\n");
                        TRX_IRQ_STATUS = B_IRQ_MAX_RT;
                        FLUSH_TX;
                        break;
                    }
                }
                RF_CE(0);
                chn++;
                if(chn>3)chn=0;
            }
        }
	}while(1);

}


void test_rf(uint8 mode){
    PRINT("TX MODE\r\n");
    RF_Init();
    test_rfTX();
    while(1);
}


