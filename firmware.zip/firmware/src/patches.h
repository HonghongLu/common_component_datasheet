#ifndef _PATCHES_H_
#define _PATCHES_H_
#include "bk2461.h"

// The PALT1 register is write-only. Keep a shadow copy of it so that
// we can track it's state

#define PALT1_INIT() \
    {g_patchPALT1=0;PALT1=g_patchPALT1;}

#define PALT1_SETB(bl) \
    {g_patchPALT1|=bl;PALT1=g_patchPALT1;}

#define PALT1_CLB(bl) \
    {g_patchPALT1&=~bl;PALT1=g_patchPALT1;}

#define PALT1_NEGB(bl) \
    {g_patchPALT1^=bl;PALT1=g_patchPALT1;}
extern uint8 g_patchPALT1;
#endif
