#include "bk2461.h"

void delay(uint8 dly){
	 while(dly--);
}

void Delay_ms(int ms)
{
    int i, j;

    for(i=0; i<ms; i++)
        for(j=0; j<1400; j++);
}

