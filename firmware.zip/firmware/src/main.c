#include <stdio.h>
#include "bk2461.h"

#include "patches.h"
#include "driver_gpio.h"
#include "driver_uart.h"
#include "driver_rf.h"
#include "driver_rtc.h"

#include "global.h"


uint8 led_on_time_m;
uint8 power_down_time_s;
uint8 radio_rx_time_ms;

// rtc_start: Configure the RTC timer to generate an interrupt in x ms.
// Normally this is called just before the processor is put in IDLE,
// and can be used to wake the processor bak up after the specificed interval.
//
// Note: the prescaler is set to 2, so the RTC clock is
// 32000/4=8kHz=125us. Thus the maximum delay possible
// with this function is 8191ms.
//
// inputs: time_ms: Interval before the RTC timer will expire, in milliseconds
// outputs: none
// side effects: Enables the RTC interrupt, and starts the RTC.
void rtc_start(uint16 time_ms)
{
    uint32  time;

    // Enable the RTC clock
    CLK_EN_CFG |= BIT(6);

    // Enable the RTC interrupt (section 12.4)
    EX6  = 1 ;
    EA   = 1 ;

    // Set the RTC counter
    time=time_ms*8;
    RTC_DATAH=  (uint8)(time/0x100);
    RTC_DATAL=  (uint8)(time%0x100);
    RTC_CFG = 0x06;
}

// rtc_interrupt: On interrupt, disable RTC. Normally this is used to wake the
// processor from IDLE, and program flow will return to the instruction
// following the one that enabled IDLE mode.
//
// inputs: (none)
// outputs: (none)
// side effects: disables RTC
void rtc_interrupt (void)  interrupt 12
{
    RTC_CFG &= 0xfb;            // Disable the RTC (clear RTC enable bit)
    RTC_CFG |= 0x10;            // Disable undocumented interrupt flag bit?

    INT_EXT = 0;                // Clear the external interrupt flag (8+4 = 12?)
}

// sleep_ms: Energy-efficient delay function, places the processor in IDLE
// mode and uses RTC for wakeup
//
// inputs: time to sleep, in milliseconds
// outputs: (none)
// side effects: Uses the RTC, puts processor in sleep (which changes peripheral clocks)
void sleep_ms(uint16 time_ms) {
    uint8 clock_state;

    WAIT_FOR_SERIAL();          // For debugging: wait until serial TX is finished

    PALT1_CLB(BIT(2));          // For debugging: disable the UART pins

    clock_state = CLK_EN_CFG;   // Save and disable peripheral clocks
    CLK_EN_CFG = 0x00;
    
    // TODO: In BK2435 documentation, this allows a lower-current sleep mode.
    // Not documented in BK2461 datasheet
    // EXSLEEP |= 0x01;           //sleep1

    rtc_start(time_ms);

    PCON2 |= 0x03;              // Set the IDLE and RC32k clock bits to enter sleep mode

    CLK_EN_CFG = clock_state;   // Restore the peripheral clock state

    PALT1_SETB(BIT(2));         // For debugging: enable the UART pins
}

// sleep_m: Energy-efficient delay function, places the processor in IDLE
// mode and uses RTC for wakeup
//
// inputs: time to sleep, in minutes
// outputs: (none)
// side effects: Uses the RTC, puts processor in sleep (which changes peripheral clocks)
//void sleep_m(uint16 time_m) {
//    // TODO
//}

// rf_setup: Set the radio up for RX function, and leave it in power down mode.
// The radio is conigured to receive fixed-length broadcast packets from a
// fixed RF channel, and ACK functionality is disabled. The radio should
// generate an interrupt if a packet is received.
//
// inputs: (none)
// outputs: (none)
// side effects: Resets the radio registers
void rf_setup() {
    // TODO
    RF_Init();

    PowerDown_RF();
    RF_CE(0);
}

// rf_start_rx: Transition the radio from power down to RX mode. The radio is
// expected to have been configured first by a call to rf_init().
//
// inputs: (none)
// outputs: (none)
// side effects: Enables the radio peripheral in RX mode (high current draw)
void rf_start_rx() {
    // TODO
}

// rf_power_down: Put the radio in power down mode. If a packet is currently
// being received, wait for it to be finished.
//
// inputs: (none)
// outputs: (none)
// side effects: Disables the radio peripheral
void rf_power_down() {
    // TODO
}

// packet_received: Check if a fixed-length packet was received, and if it
// was, copy it to the provided buffer.
//
// inputs: packet: buffer to copy the packet to, if one is ready
//         max_size: Maximum size packet that the buffer can store
// outputs: returns 1 if a packet was received, 0 otherwise. If a packet was
//         received, it is copied into *packet
// side effects: If a packet was received, remove it from the RX FIFO
bit packet_received(uint8 *packet, uint8 max_size) {
    // TODO: This is a stub version for power testing
    static uint8 count = 0;

    count++;

    PRINT("[%i]",count);

    if(count < 7)
        return 0;

    count = 0;

    packet[0] = 1;
    packet[1] = POWER_DOWN_TIME_NOMINAL;
    packet[2] = 255;
    packet[3] = RADIO_RX_TIME_NOMINAL;
    packet[4] = 0;

    return 1;
}

// check_crc: Compute the CRC of the packet, and compare it to the CRC
// located in the last byte of the packet.
//
// inputs: packet: Packet buffer to examine
//         packet_size: Size of the packet
// outputs: returns 1 if the CRC was valid, 0 otherwise
// side effects: (none)
bit check_crc(uint8 *packet, uint8 packet_size) {
    // TODO
    return 1;
}


void init_board(void) {
    PALT1_INIT();
    PALT0 = 0;                  // TODO: Does this have any effect?

    // Set all pins as high-z inputs?
    GPIO_HiZ(1, 0xFF);
    GPIO_HiZ(2, 0xFF);
    GPIO_HiZ(3, 0xFF);

    // Set all pins as inputs with pull-up enabled
//    GPIO_InputSetup(1,0xFF,0xFF,0);
//    GPIO_InputSetup(2,0xFF,0xFF,0);
//    GPIO_InputSetup(3,0xFF,0xFF,0);

    CLK_EN_CFG = 0x00;          // Turn off ADC, Timer, UART, PWM, I2C, WDT

    UartConfig(BAUD);           // For debugg

    rf_setup();

//    GPIO_OutputSetup(3, BIT(0), 0); // FlyByNight LED_EN
    GPIO_OutputSetup(2, BIT(7), 0); // Dev board LED
    LED_EN = 0;

    power_down_time_s = POWER_DOWN_TIME_NOMINAL;
    radio_rx_time_ms = RADIO_RX_TIME_NOMINAL;

    PRINT("bk2461 Initilized\r\n");
}

void main(void){
    uint8 packet[5];

    init_board();

    while(1) {
        PRINT("1");
        sleep_ms(power_down_time_s*1000);

        PRINT("2");
        rf_start_rx();

        sleep_ms(radio_rx_time_ms);

        // TODO: if we woke from a RX interrupt, disable the RTC

        PRINT("3");
        rf_power_down();

        PRINT("4");
        if(packet_received(packet, sizeof(packet)) == 0)
            continue;

        PRINT("5");
        if(check_crc(packet, sizeof(packet)) == 0)
            continue;

        PRINT("6");
        led_on_time_m = packet[0];
        power_down_time_s = packet[1];
        // Skip brightness (packet[2])
        radio_rx_time_ms = packet[3];

        PRINT("7");
        LED_EN = 1;     // turn the LED on

        //sleep_m(led_on_time_m);
        sleep_ms(2000);

        PRINT("8");
        LED_EN = 0;     // turn the LED off
    }
}
