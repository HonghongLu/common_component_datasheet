#ifndef _DRIVER_UART_H_
#define _DRIVER_UART_H_
#include "bk2461.h"

#define  SYS_CLOCK              16000000
#define  BAUD                   9600

void UartConfig(uint16 baud);
void StdioFuncConfig();
//#define printf
#endif
