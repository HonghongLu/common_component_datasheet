#ifndef _DRIVER_INT_H_
#define _DRIVER_INT_H_
#include "bk2461.h"
#define Enable_IRQ() \
	/*ʹ���ж�ϵͳ*/\
	{EA = 1;}

#define Disable_IRQ() \
	/*�ر��ж�ϵͳ*/\
	{EA = 0;}

#endif
