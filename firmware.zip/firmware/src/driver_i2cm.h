#ifndef _DRIVER_I2CM_H_
#define _DRIVER_I2CM_H_
#include "bk2461.h"
#include "patches.h"
#define I2CM_CLK_SRC			16000000l
#define I2CM_TAR_FREQ		100000

#define I2CM_SetupIO() \
    PALT1_SETB(BIT(0))


#define I2CM_OPEN_CLOCK() \
	{CLK_EN_CFG |= BIT(2);}

#define I2CM_CALC_PRES(freq) \
    ((I2CM_CLK_SRC/(freq)/10)-1)

#define I2CM_Setup(freq) \
    {\
	I2CM_PRESC = (I2CM_CALC_PRES(freq));\
	}

#define I2CM_Open() \
    {\
    I2CM_CTRL |= BIT(2);/*i2c soft reset,auto-clear if reached idle-mode*/\
    }

#define I2CM_CLOSE_CLOCK() \
	{CLK_EN_CFG &= _BIT(2);}

#define I2CM_CLOSE(pn) \
	{I2CM_CLOSE_CLOCK();}

#define I2CM_INT_SETUP(nend,sana,dna,rbf,rbe,tbf,tbe) \
    {\
    I2CM_DATA_IE |= ((rbf<<0)|(rbe<<2)|(tbf<<3)|(tbe<<5));\
    I2CM_TXRX_IE |= ((nend<<0)|(sana<<3)|(dna<<4));\
    }

#endif
