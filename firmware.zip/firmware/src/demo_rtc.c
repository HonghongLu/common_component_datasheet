#include <stdio.h>
#include <string.h>
#include "bk2461.h"
#include "driver_gpio.h"

#include "driver_rtc.h"
#define __RTC_TEST__
#ifdef __RTC_TEST__
////////////////////RESULT:NG
void test_rtc(void)
{
    uint8 tmp,tmp2,tmp3;
    GPIO_OutputSetup(2, BIT(7), 0);
    RTC_OPEN_CLOCK();
    RTC_SETUP(0,1023);
    RTC_INT_SETUP(1);
    RTC_OPEN();
    P27^=1;
    //XBYTE[0x919]=0;
    //XBYTE[0x91a]=64;
    //XBYTE[0x918]= 0x04;
    EX6 = 1;
    PRINT("%bx %bx %bx \r\n",RTC_CFG,RTC_DATAH,RTC_DATAL);
	EA = 1;
    while(1){
        }
}
void nop(void){
}
void et_isr() interrupt 12{
    EX6=0;
    AIF =0;
    nop();
    nop();
    P27^=1;
    RTC_CLEAR_INTF();

}

#endif

