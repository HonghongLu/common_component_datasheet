#include "driver_gpio.h"
#include "driver_rf.h"
#include "driver_rtc.h"
#include <stdio.h>

void test_sleep(){
    int i;
    Delay_ms(10000);
    while(1){
        RF_Init();
        //PowerDown_Rf();
        RF_CE(0);
        GPIO_InputSetup(1, 0xff, 0xff, 0);
        GPIO_InputSetup(2, 0x7f, 0x7f, 0);
        //while(P26==1);
        //Delay_ms(1000);
        GPIO_OutputSetup(2, 0x80, 0);
        GPIO_DiablePU(2, BIT(7));
        GPIO_DiablePD(2, BIT(7));
        //
        GPIO_InputSetup(3, 0xff, 0xff, 0);
        P27=0;
        TRX_ANAPWD_CTRL0 |=0x11;
        P3_WUEN=0xff;
        P3_WUMOD=0x00;
        TRX_ANAPWD_CTRL0 = 0x53;
            RTC_OPEN_CLOCK();
            RTC_SETUP(0,32768);
            RTC_INT_SETUP(1);
            RTC_OPEN();
            EX6 = 1;
            EA = 1;
        PCON2 = 0x3;
        //for(i=0;i<200;i++);
        PCON2 = 0;
        GPIO_OutputSetup(2, BIT(6), 0);
        //Delay_ms(1000);
        for(i=0;i<500;i++){
            P26=0;
            Delay_ms(1);
            P26=1;
            Delay_ms(1);
            }
        }
}

void test_sleep_1(){
   int i;
    Delay_ms(10000);
    while(1){
		PRINT("test_sleep_1\r\n");
        RF_Init();
        //PowerDown_Rf();
        RF_CE(0);
        GPIO_InputSetup(1, 0xff, 0xff, 0);
        GPIO_InputSetup(2, 0x7f, 0x7f, 0);
        //while(P26==1);
        //Delay_ms(1000);
        GPIO_OutputSetup(2, 0x80, 0);
        GPIO_DiablePU(2, BIT(7));
        GPIO_DiablePD(2, BIT(7));
        //
        GPIO_InputSetup(3, 0xff, 0xff, 0);
        P27=0;
        TRX_ANAPWD_CTRL0 |=0x11;
        //P3_WUEN=0xff;
        //P3_WUMOD=0x00;
        TRX_ANAPWD_CTRL0 = 0x53;
		
            RTC_OPEN_CLOCK();
            RTC_SETUP(0,32768);
            RTC_INT_SETUP(1);
            RTC_OPEN();
            EX6 = 1;
            EA = 1;
            
        PCON2 = 0x3;
        //for(i=0;i<200;i++);
        PCON2 = 0;
        GPIO_OutputSetup(2, BIT(6), 0);
        //Delay_ms(1000);
        PRINT("bk2461 wake up\r\n");
        for(i=0;i<500;i++){
            P26=0;
            Delay_ms(1);
            P26=1;
            Delay_ms(1);
            }
        }
}
void test_deepsleep(void)
{
    //UartTx('D');
    while(1)
    	{
    PRINT("bk2461 test_deepsleep\r\n");
	//GPIO_InputSetup(2, 0x80, 0x80, 0);

	
    P2_WUEN  = 0x80;    // P2.7 wakeup enable
    P2_WUMOD = 0x00;    // 0: �͵�ƽ����; 1: ���ػ���

	//DEEP SLEEP
	/*
    PCON2 = 0x08;       // enter deepsleep: ������
    PCON2 = 0x00;       // ������ 
    */
    
    TRX_ANAPWD_CTRL0 |=0x11;
	//nop();
	//nop();
	TRX_ANAPWD_CTRL0 = 0x53;
	PCON2 = 0x3;
	PCON2 = 0;
	
    //UartTx('S');
    Delay_ms(100);
    PRINT("bk2461 wake up\r\n");
    }
    //while(1);
}
void test_sleep_2(){
    int i;
    Delay_ms(10000);
    while(1){
		PRINT("test_sleep_2\r\n");
        RF_Init();
        //PowerDown_Rf();
        RF_CE(0);
        //GPIO_InputSetup(1, 0xff, 0xff, 0);
        //GPIO_InputSetup(2, 0x7f, 0x7f, 0);
        //while(P26==1);
        //Delay_ms(1000);
        //GPIO_OutputSetup(2, 0x80, 0);
        //GPIO_DiablePU(2, BIT(7));
        //GPIO_DiablePD(2, BIT(7));
        //
        //GPIO_InputSetup(3, 0xff, 0xff, 0);
        //P27=0;
        TRX_ANAPWD_CTRL0 |=0x11;
        P3_WUEN=0xff;
        P3_WUMOD=0x00;
        TRX_ANAPWD_CTRL0 = 0x53;
		/*
            RTC_OPEN_CLOCK();
            RTC_SETUP(0,32768);
            RTC_INT_SETUP(1);
            RTC_OPEN();
            EX6 = 1;
            EA = 1;
            */
        PCON2 = 0x3;
        //for(i=0;i<200;i++);
        PCON2 = 0;
        //GPIO_OutputSetup(2, BIT(6), 0);
        //Delay_ms(1000);
        Delay_ms(100);
    PRINT("bk2461 wake up\r\n");
	/*
        for(i=0;i<500;i++){
            P26=0;
            Delay_ms(1);
            P26=1;
            Delay_ms(1);
            }*/
        }
}

void nop(){
}

void et_isr() interrupt 12{
    EX6=0;
    AIF =0;
    nop();
    nop();
//    P27^=1;
    RTC_CLEAR_INTF();

}

