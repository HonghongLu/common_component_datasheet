#include <stdio.h>
#include <string.h>

#include "bk2461.h"
#include "driver_gpio.h"
#include "driver_rf.h"

code char P0_Address[5] =
#ifndef _RF_PN9TEST_
	{0x15, 0x59, 0x23, 0xC6, 0x29};
#else
	{0x0e, 0xdc, 0xe5, 0x95, 0x02};
#endif

code char P1_Address[5] =
    {0x10, 0x56, 0x24, 0xCD, 0x78};

code uint8 Cfg_0c_Val[4] =
    {0x00, 0x1A, 0x33, 0x28};
code uint8 Cfg_0d_Val[4] =
    {0x37, 0xB7, 0x80, 0xD0};
code uint8 Ramp_Table_Val[11] =
    {0x04, 0x41, 0x20, 0x08, 0x03, 0x51, 0x18, 0x88, 0xC2, 0x34, 0x0F};

code uint32 Ana_Init_Val[9] = {
/*
    0xC080C444,
    0x90F78960,
    0x01B6C631,
    0xB8D51782,
    0xB996821B,
    0x32048064,
    0xA85517A2,
    0x0A2C8968,
    //*/
#if _RF_DR_TAR_ == _RF_DR_1M_
	///*1M-dr
	///*
    B2L_32(0x44C4C086),
    B2L_32(0x6089C391),
    B2L_32(0x3129CFD3),
    B2L_32(0x8217D5B8),
    B2L_32(0x1B8296B9),
    B2L_32(0x64800432),
    B2L_32(0xA21B56A8),
    //B2L_32(0x87992C0A),
    B2L_32(0x87992C0C),//��Ϊ��adƫ���޸�
    B2L_32(0x00000000),
    //*/
#elif _RF_DR_TAR_ == _RF_DR_2M_
    ///*2M-dr
    B2L_32(0x44C4C086),
    B2L_32(0x6089C391),
    B2L_32(0x25864F10),
    B2L_32(0x8217D5B8),
    B2L_32(0x1B8296B9),
    B2L_32(0x77800432),
    B2L_32(0xA01B56A8),
    B2L_32(0x87892C0A),
    B2L_32(0x00000000),
    //*/
#else
    B2L_32(0x44C4C086)|BIT(30),
    B2L_32(0x6089C391),
    B2L_32(0x25864F10),
    B2L_32(0x8217D5B8),
    B2L_32(0x1B8296B9),
    B2L_32(0x77800432),
    B2L_32(0xA01B56A8),
    B2L_32(0x87892C0A),
    B2L_32(0x00000000),

#endif
    //
};

void Write_Reg_Ana(uint8 addr, uint32 val)
{
    uint8 buf[4];

    buf[3] = (val>>24) & 0xFF;        // MSB
    buf[2] = (val>>16) & 0xFF;
    buf[1] = (val>>8) & 0xFF;
    buf[0] =  val & 0xFF;             // LSB

    while( !(TRX_SCTRL & 0x80) );
    memcpy (&TRX_SDATA_0, buf, 4);    // data
    TRX_SCTRL = addr;                 // address
}

void PowerUp_Rf(void)
{
    TRX_CONFIG |= 0x02;
}

void PowerDown_Rf(void)
{
    TRX_CONFIG &= 0xFD;
}

void SwitchToRxMode(void)
{
    PowerUp_Rf();
    FLUSH_RX;
    TRX_CE = 0;
    TRX_CONFIG |= 0x01;
    TRX_CE = 1;
}

void SwitchToTxMode(void)
{
    PowerUp_Rf();
    FLUSH_TX;
    TRX_CE = 0;
    TRX_CONFIG &= 0xFE;
    TRX_CE = 1;
}

void ChangeTxPipe(uint8 pipe)
{
    uint8 tmp_address[5];

    switch(pipe)
    {
        case 0:
            memcpy(&TRX_RX_ADDR_P0_0, P0_Address, 5);
            memcpy(&TRX_TX_ADDR_0, P0_Address, 5);
            memcpy(&TRX_RX_ADDR_P1_0, P1_Address, 5);
            break;

        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
            memcpy(tmp_address, P1_Address, 5);

            if(pipe == 2)                              // For P1, need not change LSB
                tmp_address[0] = TRX_RX_ADDR_P2;
            else if(pipe == 3)
                tmp_address[0] = TRX_RX_ADDR_P3;
            else if(pipe == 4)
                tmp_address[0] = TRX_RX_ADDR_P4;
            else if(pipe == 5)
                tmp_address[0] = TRX_RX_ADDR_P5;

            memcpy(&TRX_RX_ADDR_P0_0, tmp_address, 5);
            memcpy(&TRX_TX_ADDR_0, tmp_address, 5);
            memcpy(tmp_address, P1_Address, 5);
            tmp_address[2] = 0x37;                          // avoid for 2 same address for R1, R2, ... R5
            memcpy(&TRX_RX_ADDR_P1_0, tmp_address, 5);
            break;

        default:
            break;
    }
}

void R_RX_PAYLOAD(uint8 *pBuf, uint8 bytes)
{
    uint8 i;

    TRX_CMD = 0x40;                   // command
    for(i=0; i<bytes; i++)
        pBuf[i] = TRX_FIFO;           // data
    TRX_CMD = 0x00;                   // end: nop command
}

void W_TX_PAYLOAD(uint8 *pBuf, uint8 bytes)
{
    uint8 i;

    TRX_CMD = 0x60;
    for(i=0; i<bytes; i++)
        TRX_FIFO = pBuf[i];
    TRX_CMD = 0x00;
}

void W_TX_PAYLOAD_NOACK(uint8 *pBuf, uint8 bytes)
{
    uint8 i;

    TRX_CMD = 0x68;
    for(i=0; i<bytes; i++)
        TRX_FIFO = pBuf[i];
    TRX_CMD = 0x00;
}

void W_ACK_PAYLOAD(uint8 *pBuf, uint8 bytes, uint8 pipe)
{
    uint8 i;

    TRX_CMD = 0x68 + pipe;
    for(i=0; i<bytes; i++)
        TRX_FIFO = pBuf[i];
    TRX_CMD = 0x00;
}
extern void waitForKey();
void RF_Kmod_Calibration(){
	uint8 t;
	uint32 b;
	uint16 a;
    ///*
	//PRINT("kmod_calibration entry\r\n");
	// ���뷢��ģʽ��bank0.0Hex=0EHex����CE���ߣ�bank0.35Hex=01Hex����
	SwitchToTxMode();
	//
	// Bypass gated clock��bank0.22Hex<7>=1����
	TRX_CFG_0C_0 |= BIT(7);
	// ��channelΪ0��bank0.5Hex<6:0>=0����
	//RF_Set_Chn(0);
	// ����fm_gain = 0x100; (dig_0x5a<0>=1; dig_0x5b<7:0>=0x00)
	TRX_FM_GAIN_B0_7 =0;
	TRX_FM_GAIN_B8 = 1;
	// ����1M����ģʽBank0.6Hex=07Hex / 2MģʽBank0.6Hex=0fHex / 250KģʽBank0.
	//6Hex=27Hex
	#if _RF_DR_TAR_==_RF_DR_1M_
    t=0x07;
    #elif _RF_DR_TAR_==_RF_DR_2M_
    t=0x0f;
    #else
    t=0x27;
    #endif
	//t=(dr==_RF_DR_1M_)?0x07:(dr==_RF_DR_2M_?0x0f:0x27);
	TRX_RF_SETUP = t;
    //RF_SetupDR(1 M);
	// ����ģʽ��Bank1. Reg1 = 0x90F7C960��Bank1.Reg2 = 0x01B6C632����
	RF_PLL_MODE(0);

	// ���뵥�ز�ģʽ��bank0.63Hex<5>=1����
	TRX_ANAPWD_CTRL0 |= BIT(5);

	// VCOУ׼��Bank1.Reg4 = 0xBB96821B, wait for 1ms, Bank1.Reg4 = 0xB996821B��
	Write_Reg_Ana(4, 0xBB96821B);
	//wait for 1ms
	Delay_ms(2);
	Write_Reg_Ana(4, 0xB996821B);

	// ���� kmod_coff
 	// Bank0.5cHex<0>=1Hex Bank0.5dHex<7:0>=0Hex
	TRX_FM_KMOD_SET_B0_7 = 0;
	TRX_FM_KMOD_SET_B8 = BIT(0);

	// Bank0.59Hex<0>=0Hex��
	TRX_PLL_SDM &= _BIT(0);
	// Wait for 10us
	Delay_ms(1);
	// Bank0.59Hex<0>=1Hex��
	TRX_PLL_SDM |= BIT(0);
	// Wait for 20ms
	Delay_ms(30);

	// ����frequency deviation
	a = TRX_KCAL_OUT_B0_7;
	a += ((TRX_KCAL_OUT_B8_9&0x03) <<8);
	// A1=bank0.3eHex<1:0>, A2=bank0.3fHex<7:0>
	// Fd_measure=A1,A2Hex=A(dec)

	// ����Ӧ�����õ�fm_gain
	// fm_gain(Hex)=5aH<0>,5bH<7:0>;
	// 1Mģʽfm_gain(Dec)=300*256/A / 2M ģʽfm_gain(Dec)=600*256/A / 250Kģʽfm_gain
	// (Dec)=160*256/A
	//	��fm_gain���ý�5aH<0>,5bH<7:0>��
	#if _RF_DR_TAR_ == _RF_DR_1M_
    b=300l*256;
    #elif _RF_DR_TAR_ ==_RF_DR_2M_
    b=600l*256;
    #else
    b=160l*256;
    #endif
	b/=a;
//	PRINT("%d\r\n",a);
//	PRINT("%ld\r\n",b);
	if(b>=BIT(9))b=BIT(9)-1;
    //��У��ֵд��
	TRX_FM_GAIN_B8 &= (_BIT(0));
	TRX_FM_GAIN_B8 |= ((b>>8)&BIT(0));
	TRX_FM_GAIN_B0_7 = (b&0xff);

	// ����ģʽ��Bank1.Reg1 = 0x90F78960, Bank1.Reg2 = 0x01B6C631��
	RF_PLL_MODE(1);
#if 0
#endif

	// bank0.63Hex<5>=0, bank0.22Hex<7>=0, Bank0.59Hex<0>=0Hex
	TRX_ANAPWD_CTRL0 &= _BIT(5);
	TRX_CFG_0C_0 &= _BIT(7);
	TRX_PLL_SDM &= _BIT(0);
	//PRINT("kmod_calibration end\r\n");
	//*/
}

void RF_Init(void)
{
    uint8 i;

    // ��ʼ��ģ��Ĵ���
    for(i=0; i<9; i++)
        Write_Reg_Ana(i, Ana_Init_Val[i]);

    // ���ù���
    TRX_GPA0 = 0x05;
    TRX_GPA1 = 0xF8;

    // �ر�ģʽѡ���·
    #define __FLASH_DEBUGING__
    #ifndef __FLASH_DEBUGING__
    TRX_ANAPWD_CTRL0 |= 0x11;
    #endif
    TRX_PLL_SDM &= _BIT(4);
    // ��ʼ��cfg_0C, cfg_0D
    memcpy(&TRX_CFG_0C_0, Cfg_0c_Val, 4);
    memcpy(&TRX_CFG_0D_0, Cfg_0d_Val, 4);
    memcpy(&TRX_RAMP_TABLE_0, Ramp_Table_Val, 11);
    //RF_SetupDR(1 M);
    #if _RF_DR_TAR_ == _RF_DR_1M_
        RF_SetupDR(1 M);
    #elif _RF_DR_TAR_ == _RF_DR_2M_
        RF_SetupDR(2 M);
    #else
        RF_SetupDR(250 K);
    #endif
    RF_Kmod_Calibration();
    // ��ʼ��ģ��Ĵ���
    for(i=0; i<9; i++)
        Write_Reg_Ana(i, Ana_Init_Val[i]);
    ///*
    RF_SetupCRC(1, 2);
    //TRX_CONFIG     = 0x0C;    // default PRX

    RF_EnAA(BIT(0)|BIT(1)|BIT(2)|BIT(3)|BIT(4)|BIT(5));
    //TRX_EN_AA      = 0x3F;

    RF_EnRxAddr(BIT(0)|BIT(1)|BIT(2)|BIT(3)|BIT(4)|BIT(5));
    //TRX_EN_RXADDR  = 0X3F;

    RF_SetAddrWidth(5);
    //TRX_SETUP_AW   = 0x03;

    //RF_SetupRetrans(1000, 3);
    //TRX_SETUP_RETR = 0x33;

    //RF_TX_FREQERR()=0;
    RF_Set_Chn(0);
    //TRX_RF_CH      = 0x00;
    /*
	*/
#if _RF_DR_TAR_ == _RF_DR_1M_
    RF_Setup(1 M, 0, 1);
#elif _RF_DR_TAR_ == _RF_DR_2M_
	RF_Setup(2 M, 0, 1);
#else
	RF_Setup(250 K, 0, 1);
#endif
    //TRX_RF_SETUP   = 0x0D;
	//�趨�շ�pipe��ַ
    memcpy(&TRX_RX_ADDR_P0_0, P0_Address, 5);
    memcpy(&TRX_RX_ADDR_P1_0, P1_Address, 5);
    TRX_RX_ADDR_P2 = 0x11;
    TRX_RX_ADDR_P3 = 0x12;
    TRX_RX_ADDR_P4 = 0x13;
    TRX_RX_ADDR_P5 = 0x14;
    memcpy(&TRX_TX_ADDR_0, P0_Address, 5);
	//�趨ÿ��pipe��payload����
	RF_Set_PipePL(0, 0x20);
	RF_Set_PipePL(1, 0x20);
	RF_Set_PipePL(2, 0x20);
	RF_Set_PipePL(3, 0x20);
	RF_Set_PipePL(4, 0x20);
	RF_Set_PipePL(5, 0x20);
	//TRX_DYNPD    = 0x3F;
	RF_EnDyncPL(0x3f);
    //TRX_FEATURE  = 0x07;
	RF_SetupFeature(1, 1, 1);
    ///*
    RF_Set_Chn(0);
    ///*
    RF_SetupRetrans(250, 3);
    //TRX_SETUP_RETR = 0xff;
    //*/
    RF_SetTxPower_12dBm();
//    TRX_PLL_SDM &= 0xEF;    // open_loop_en=0
    PowerDown_Rf();
//*/
}

void RF_SingleWaveTest(uint8 chn,uint8 pwr){
    uint8 i=0;
    PRINT("enter rf single-wave test func\r\n");
	// ����ģʽ��Bank1. Reg1 = 0x90F7C960��Bank1.Reg2 = 0x01B6C632����
	RF_PLL_MODE(0);
    //����TXģʽ
    TRX_CONFIG =0x0e;
    //CE���ߣ�bank0.35Hex=01Hex����
    RF_CE(1);
	// ���뵥�ز�ģʽ��bank0.63Hex<5>=1����
	TRX_ANAPWD_CTRL0 |= BIT(5);

	// Bypass gated clock��bank0.22Hex<7>=1����
	TRX_CFG_0C_0 |= BIT(7);
	// ��channelΪ0��bank0.5Hex<6:0>=0����
	RF_Set_Chn(chn);
    //
    //RF_SetTxPower(pwr);
    //RF_SetTxPower_0dBm();
    RF_SetTxPower_12dBm();

	PRINT("exit rf single-wave test func\r\n");

}

void RF_BerRX(uint8 chn){
    // step begin
    RF_Set_Chn(chn);
    SwitchToRxMode();
    // step 1,�������ģʽ,�������л�������
    //TRX_CONFIG = 0x0f;
    // step 2,CE���ߣ��Ѱ������л�������
    //RF_CE(1);

    // step 3,�趨pipe��ַ���Ѱ����ڳ�ʼ��������

    // step 4��ʹ��pn9���պ�ber������
    TRX_CFG_0C_0 |= BIT(5);
    Delay_ms(20);
    TRX_CFG_0C_0 |= BIT(6);

    // step 5,�����յ���bit�����ͳ�����bit��
    PRINT("ber=%02bx%02bx%02bx%02bx\r\n",
	    TRX_BER_CNT_ERR_3,TRX_BER_CNT_ERR_2,
	    TRX_BER_CNT_ERR_1,TRX_BER_CNT_ERR_0);
    PRINT("total bits=%02bx%02bx%02bx%02bx\r\n",
	    TRX_BER_CNT_RCV_3,TRX_BER_CNT_RCV_2,
	    TRX_BER_CNT_RCV_1,TRX_BER_CNT_RCV_0);

    // step end
    TRX_CFG_0C_0 = 0;
    RF_CE(0);
}

void RF_Pn9TX(uint8 chn){
    // step begin
    RF_Set_Chn(chn);
    SwitchToTxMode();
    // step 1,����txģʽ
    //TRX_CONFIG = 0x0e;

    // step 2,�趨pipe��ַ

    // step 3��ʹ��pn9���պ�ber������
    TRX_CFG_0C_0 |= (BIT(7)|BIT(4));
}

void RF_Pn9StopTX(){
    // step end
    TRX_CFG_0C_0 = 0;
    RF_CE(0);
}

void RF_TxAt(uint8 chn,uint8 pipe,uint8*buf,uint8 sz){
    RF_Set_Chn(chn);
    SwitchToTxMode();
    //TRX_IRQ_STATUS = 0x70;
    //RF_SetupInterrupt(B_IRQ_MAX_RT|B_IRQ_TX_DS|B_IRQ_RX_DR);

    while(TRX_FIFO_STATUS & B_FIFO_TX_FULL);    // Wait for TX_FIFO empty
    W_TX_PAYLOAD(buf, sz);
}

