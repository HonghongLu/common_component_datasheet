#ifndef _APP_RF_H_
#define _APP_RF_H_

void test_rf(uint8 mode);

#endif
