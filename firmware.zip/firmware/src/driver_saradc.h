#ifndef _DRIVER_SARADC_H_
#define _DRIVER_SARADC_H_
#include "bk2461.h"
#include "patches.h"

#define ADC_SetupIO(n) \
	PALT1_SETB(BIT(n))

#define ADC_OPEN_CLOCK() \
	{CLK_EN_CFG |= 0x80;}

#define ADC_CLOSE_CLOCK() \
	{CLK_EN_CFG &= ~0x80;}

#define ADC_OPEN() \
	{ADC_CTL |= BIT(1);}

#define ADC_CLOSE() \
	{\
	ADC_CTL &= _BIT(1);\
	ADC_CLOSE_CLOCK();\
	}

#define ADC_MODE_PD \
    0

#define ADC_MODE_Single \
    1

#define ADC_MODE_Soft \
    2

#define ADC_MODE_Continue \
    3

#define ADC_SETUP(pres,sr,mode,chn,_12bits) \
    {\
    ADC_CTL=(((mode&3)<<6)|((chn&7)<<3));\
    ADC_DATAH= ((1<<7)|((pres&0x7)<<4));\
    ADC_RATE =(sr&0xff);\
    ADC_CTL2 = (((sr>>8)&0x0f)|(_12bits<<7)|(3<<5));\
    }

#define ADC_SWITCH_CHN(chn) \
    {\
    ADC_CTL &=(~((7)<<3));\
    ADC_CTL |=(((chn)<<3));\
    }

#define ADC_INT_SETUP(inte) \
    {\
    ADC_CTL |= BIT(2);\
    EX8 = inte;\
    }

#define ADC_CHECK_RDY() \
    (ADC_CTL & BIT(0))

#define ADC_12bitSetup(pres,sr,chn) \
    ADC_SETUP(pres, sr, ADC_MODE_Continue, chn, 1);

#define ADC_10bitSetup(pres,sr,chn) \
    ADC_SETUP(pres, sr, ADC_MODE_Soft, chn, 0);

#define ADC_CLEAR_INTF() \
    {INT_ADC = 0;}

#endif
