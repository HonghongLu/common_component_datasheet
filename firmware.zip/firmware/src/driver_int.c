#include "bk2461.h"
#include "global.h"
#include "driver_gpio.h"
#include "driver_saradc.h"

void rf_isr() interrupt 11
{
	//TRX_FIFO_STATUS
	//TRX_IRQ_STATUS
	if(TRX_IRQ_STATUS&B_IRQ_RX_DR){
		//RF��������ready
		TRX_IRQ_STATUS |= B_IRQ_RX_DR;
	}
	if(TRX_IRQ_STATUS&B_IRQ_TX_DS){
		//RF�����Ѿ�����
		TRX_IRQ_STATUS |= B_IRQ_TX_DS;
	}
}


void ex1_isr() interrupt 2{
}


void uart_isr() interrupt 4{
}
void et2_isr() interrupt 5{
}
void i2cm_isr() interrupt 9{
}


