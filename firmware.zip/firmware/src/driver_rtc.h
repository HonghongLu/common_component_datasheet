#ifndef _DRIVER_RTC_H_
#define _DRIVER_RTC_H_
#include "bk2461.h"
#define RTC_SRC_CLOCK 32000
#define RTC_PRNT printf
#define RTC_OPEN_CLOCK() \
    {\
    CLK_EN_CFG |= BIT(6);\
    }

#define RTC_CLOSE_CLOCK() \
    {\
    CLK_EN_CFG &= _BIT(6);\
    }
#define RTC_GET_DIV(pres,freq) \
    (RTC_SRC_CLOCK/(freq*(pres+2))-1)

#define RTC_SETUP(pres,freq) \
    {\
    RTC_CFG = ((pres&0x03));\
    RTC_DATAH = ((freq>>8)&0xff);\
    RTC_DATAL = (freq&0xff);\
    }

#define RTC_OPEN() \
    {RTC_CFG |=BIT(2);}

#define RTC_CLOSE() \
    {\
    RTC_CFG &=_BIT(2);\
    RTC_CLOSE_CLOCK();\
    }

#define RTC_INT_SETUP(en) \
    {\
    EX6 = (en);\
    }
#define RTC_CLEAR_INTF() \
    {RTC_CFG |= BIT(4);}

#endif
