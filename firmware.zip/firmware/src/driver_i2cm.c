#include <stdio.h>
#include <string.h>

#include "bk2461.h"
#include "driver_i2cm.h"
#include "app_uart.h"
#include "driver_gpio.h"


#define I2CM_STATUS_TBE \
    (BIT(5)&I2CM_DATA_STS)

#define I2CM_STATUS_TBF \
    (BIT(3)&I2CM_DATA_STS)

#define I2CM_STATUS_RBE \
    (BIT(2)&I2CM_DATA_STS)

#define I2CM_STATUS_RBF \
    (BIT(0)&I2CM_DATA_STS)

#define I2CM_STATUS_DNA \
    (BIT(4)&I2CM_TXRX_STS)

#define I2CM_STATUS_UnderFlow \
    (BIT(2)&I2CM_TXRX_STS)

#define I2CM_STATUS_OverFlow \
    (BIT(1)&I2CM_TXRX_STS)

#define I2CM_STATUS_SAddrNAK \
    (BIT(4)&I2CM_TXRX_STS)

#define I2CM_STATUS_NEND \
    (BIT(0)&I2CM_TXRX_STS)

#define ERRNO_IDLE 0
#define ERRNO_RUNNING 1
#define ERRNO_EndSUCCESS     2
#define ERRNO_FAIL     2


uint8 errno_i2c;
extern void waitForKey();
#define __I2C_SW__
#ifdef __I2C_SW__
#define SCL \
    P22

#define SDA \
    P23

#define SDA_DIR_IN() \
    GPIO_InputSetup(2, BIT(3), 0,0)

#define SDA_DIR_OUT() \
    GPIO_OutputSetup(2, BIT(3), 0)

#define I2C_SB() \
    {\
    SDA = 0;\
    delay(5);\
    SCL = 0;\
    }

#define I2C_STP() \
    {\
    SDA=0;\
    delay(10);\
    SDA = 1;\
    delay(5);\
    SCL = 1;\
    }

#define I2C_TxBIT(b) \
    {\
    SDA = b;\
    delay(3);\
    SCL = 1;\
    delay(5);\
    SCL = 0;\
    }

#define I2C_ACK() \
    I2C_TxBIT(0)


extern void delay(uint8 dly);

void I2C_Init(){
    GPIO_OutputSetup(2, BIT(2)|BIT(3), BIT(2)|BIT(3));
    SCL = 1;
    SDA = 1;
}

bit I2C_RxACK(){
	bit a;
    SDA_DIR_IN();
    delay(2);
    SCL = 1;
    delay(2);
    a = SDA;
    delay(2);
    SCL = 0;
    SDA_DIR_OUT();
    return(a);
}

bit _TxByte(uint8 dat){
    uint8 i;
    bit a;
    for(i=0;i<8;i++){
        I2C_TxBIT((dat&BIT(7))!=0);
        dat <<= 1;
    }
    a=I2C_RxACK();
    if(a){
        I2C_STP();
        }
    return(a);
}
uint8 _RxByte(){
    uint8 i;
    uint8 a=0;
    uint8 b;
    for(i=0;i<8;i++){
        SCL = 1;
        delay(2);
        b=SDA;
        a=(a<<1)+b;
        delay(2);
        SCL = 0;
        delay(2);
    }
    return(a);
}

void I2C_SendByte(uint8 devAddr,uint8 regAaddr,uint8 dat){
    //SB
    I2C_SB();
    //devAddr
    if(_TxByte(devAddr<<1))return;
    //regAaddr
    if(_TxByte(regAaddr))return;
    //dat
    if(_TxByte(dat))return;
    //STP
    I2C_STP();
}

void I2C_Send(uint8 devAddr,uint8 regAaddr,uint8 *buf,uint8 rpt){
    uint8 i;
    //SB
    I2C_SB();
    //devAddr
    if(_TxByte(devAddr<<1))return;
    //regAaddr
    if(_TxByte(regAaddr))return;
    //dat
    for(i=0;i<rpt;i++){
        if(_TxByte(buf[rpt]))return;
    }

    //STP
    I2C_STP();
}

uint8 I2C_ReadByte(uint8 devAddr,uint8 regAaddr){
    uint8 t;
    errno_i2c = 1;
    //SB
    I2C_SB();
    //devAddr
    if(_TxByte(devAddr<<1))return(0);
    //regAaddr
    if(_TxByte(regAaddr))return(0);
    I2C_STP();
    delay(10);
    I2C_SB();
    //devAddr
    if(_TxByte((devAddr<<1)|1))return(0);
    //rx dat
    SDA_DIR_IN();
    t=_RxByte();
    SDA_DIR_OUT();
    I2C_TxBIT(1);//NAK
    //STP
    I2C_STP();
    errno_i2c = 0;
    return(t);
}

void test_i2cm(){
    uint8 i,dat,j;
    waitForKey();
    PRINT("enter test:\r\n");
    I2C_Init();
    i=0;j=0;
    while(1){
        PRINT("start test:\r\n");
        for(j=0;j<20;){
            dat=I2C_ReadByte(0x50, i);
            if(errno_i2c==0){
                PRINT("%02bx\r\n",dat);
                dat ++;
                Delay_ms(3);
                I2C_SendByte(0x50, 0, dat);
                Delay_ms(100);
                j++;
                }
        }
        PRINT("end test\r\n");
        while(1);
    }
}

#endif

//#define __I2C_HW__

#ifdef __I2C_HW__
#define I2CM_STARTBIT() \
    {\
    I2CM_CTRL |= BIT(1);\
    }
void I2CM_Init(){
	 I2CM_OPEN_CLOCK();
	 I2CM_SetupIO();//P22=SCL,P23=SDA
     I2CM_Setup(100000);
     I2CM_Open();
     while(I2CM_CTRL&BIT(2));
}

void I2CM_SendByte(uint8 devAddr,uint8 regAaddr,uint8 dat){
    I2CM_CALLADDR0 = (((devAddr)&0x7f));
    I2CM_TXDATA = regAaddr;
    I2CM_STARTBIT();
    while(I2CM_STATUS_TBE == 0);
    //I2CM_CALLADDR0 = (((devAddr)&0x7f));
    I2CM_TXDATA = dat;
    //I2CM_STARTBIT();
    while(I2CM_STATUS_TBE== 0){
        PRINT("[txrx status]=%02bx [data status]=%02bx\r\n",I2CM_TXRX_STS,I2CM_DATA_STS);
        }
}

void I2CM_Send(uint8 devAddr,uint8 regAaddr,uint8 *buf,uint8 rpt){
    I2CM_CALLADDR0 = (((devAddr)&0x7f));
    I2CM_TXDATA = regAaddr;
    I2CM_STARTBIT();
    while(I2CM_STATUS_TBE == 0);
    I2CM_CALLADDR0 = (((devAddr)&0x7f));
    I2CM_TXDATA = *buf++;
    rpt--;
    I2CM_STARTBIT();
    for(;rpt>0;rpt--){
	    while(I2CM_STATUS_TBE == 0);
        I2CM_TXDATA = *buf++;
    }
}

uint8 I2CM_ReadByte(uint8 devAddr,uint8 regAaddr){
    I2CM_CALLADDR0 = (((devAddr)&0x7f));
    I2CM_TXDATA = regAaddr;
    I2CM_STARTBIT();
    //while(I2CM_STATUS_TBF);
    while(I2CM_STATUS_TBE == 0);
    //{
    //    PRINT("[txrx status]=%02bx [data status]=%02bx\r\n",I2CM_TXRX_STS,I2CM_DATA_STS);
    //    }
    I2CM_CALLADDR0 = (((devAddr)&0x7f))|(1<<7);
    I2CM_STARTBIT();
    while(I2CM_STATUS_RBF == 0);
    //{
    //    PRINT("[txrx status]=%02bx [data status]=%02bx\r\n",I2CM_TXRX_STS,I2CM_DATA_STS);
    //    }
    return(I2CM_RXDATA);
}

void I2CM_Read(uint8 devAddr,uint8 regAaddr,uint8*buf,uint8 rpt){
    I2CM_CALLADDR0 = (((devAddr)&0x7f));
    I2CM_TXDATA = regAaddr;
    I2CM_STARTBIT();
    //while(I2CM_STATUS_TBF);
    while(I2CM_STATUS_TBE == 0);
    I2CM_CALLADDR0 = (((devAddr)&0x7f))|(1<<7);
    I2CM_STARTBIT();
    for(;rpt>0;rpt--){
        while(I2CM_STATUS_RBF == 0){
            PRINT("[txrx status]=%02bx [data status]=%02bx\r\n",I2CM_TXRX_STS,I2CM_DATA_STS);
            }
        *buf++ = I2CM_RXDATA;
    }
}

uint8 eebuf[8];
void test_i2cm(){
    uint8 i,dat,j;
    waitForKey();
    I2CM_Init();
    i=0;j=0;
    memset(eebuf,0,8);
    while(1){
        for(j=0;j<20;j++){
            dat=I2CM_ReadByte(0x50, i);
            dat ++;
            Delay_ms(3);
            I2CM_SendByte(0x50, 0, dat);
            Delay_ms(100);
        }
        while(1);
        //Delay_ms(100);
        //dat=I2CM_ReadByte(0x50, i);
        //PRINT("[%bd]=%bx\r\n",i,dat);
        //I2CM_Read(0x50, i, eebuf, 8);
        //PRINT("read from %bd-%bd is:\r\n",i,i+8);
        //for(dat=0;dat<8;dat++){
        //    PRINT("0x%02bx ",eebuf[dat]);
        //}
        //PRINT("\r\n");
        //i+=8;
        //i&=0x3f;
        }
}
#endif

