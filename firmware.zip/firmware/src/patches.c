#include "patches.h"
uint8 g_patchPALT1;

