#include <stdio.h>


#include "bk2461.h"
#include "driver_gpio.h"
#include "driver_pwm.h"

#include "driver_rf.h"

void test_rf_testing(){
	 uint8 mode=1;
     ///*
	 GPIO_InputSetup(2, BIT(6)|BIT(7), BIT(6)|BIT(7), 0);
     PRINT("wait for press P26(TX PN9) or P27(RX PN9)...\r\n");
     while((P26==1 && P27==1));
     if(P26 == 0)mode=0;
     if(P27 == 0)mode=1;
     //*/
     switch(mode){
        case 0:
            PRINT("PN9 TX MODE\r\n");
            RF_Pn9TX(3);
            while(1);
            break;
        case 1:
            PRINT("RX PN9 MODE\r\n");
            while(1){
                RF_BerRX(3);
                }
            break;
        }
     PRINT("error\r\n");
     while(1);
}

