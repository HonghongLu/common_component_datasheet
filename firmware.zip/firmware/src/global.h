/*------------------------------------------------------------------------------
#include <REG51.H>
global.h

Declaration of global variables
------------------------------------------------------------------------------*/
#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#define LED_ON_TIME_MIN             1
#define LED_ON_TIME_MAX             100

#define POWER_DOWN_TIME_MIN         1
#define POWER_DOWN_TIME_NOMINAL     10
#define POWER_DOWN_TIME_MAX         30

#define RADIO_RX_TIME_MIN           32
#define RADIO_RX_TIME_NOMINAL       50
#define RADIO_RX_TIME_MAX           100


//#define LED_EN                      (P30)           // LED enable signal on P3.0
#define LED_EN                      (P27)           // Dev board LED on P2.7


#define WAIT_FOR_SERIAL() \
    {while (!TI);}


#endif
