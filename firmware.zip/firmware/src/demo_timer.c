/*
����timer�ĸ���ģʽ
Timer 0 & Timer 1:
    Mode 0: 13-bit timer
    Mode 1: 16-bit timer
    Mode 2: Auto reload 8-bit timer
    Mode 3:(Timer 0) Two 8-bit timer
            TL0 for Timer 0 intterupt
            TH0 for Timer 1 interrupt
Timer 2: ��2461��Timer 2��PIN��Timer2Capt Signal
    Mode 0: 16-bit timer
    Mode 2: Baud rate generator ��Ϊ�����ʷ������ο�UartConfig()
*/

//#include "common.h"
#include "bk2461.h"
#include "driver_timer.h"
#include "driver_rf.h"
#include "driver_gpio.h"

xdata uint8 Fifo_Data1[32];
const uint8 tblRfChn[]={39,39,39,39};
xdata uint16 txPktId=0;
xdata uint8 curChn=0;
void StartRfTX(uint8 chn,char*buf,uint8 len){
    RF_Set_Chn(chn);
    delay(100);
    SwitchToTxMode();
    FLUSH_TX;
    FLUSH_RX;
    RF_SetupInterrupt(B_IRQ_MAX_RT|B_IRQ_TX_DS|B_IRQ_RX_DR);
    while(TRX_FIFO_STATUS & B_FIFO_TX_FULL);    // Wait for TX_FIFO empty
    W_TX_PAYLOAD(buf, len);
}

void ClearFifo(){
    uint8 i;
    for(i=0;i<32;i++)Fifo_Data1[i]=0;
}
uint8 cntN=0;
////////////////////RESULT:
void test_tmr(void)
{
    GPIO_OutputSetup(2, BIT(7)|BIT(6), 0);
    //�趨timer0Ϊ1ms
    //TIMER0_16bit_SETUP(1000, 0);//��Ϊ16λ1000Hz�ж�
    TIMER0_8bitAR_SETUP(10000, 0);//��Ϊ8λ���Զ���װ���ܵ�10k�ж�
    //�趨timer1Ϊ2ms
    //TIMER1_16bit_SETUP(200, 0);//��Ϊ16λ500Hz�ж�
    TIMER1_13bit_SETUP(250, 0);//��Ϊ13λ1000Hz�ж�
    //��timer0
    TIMER0_INT_SETUP(1);
    TIMER0_OPEN();
    //��timer1
    TIMER1_INT_SETUP(1);
    TIMER1_OPEN();
    //
    Rf_Init();
    ChangeTxPipe(2);

    //���ж�ϵͳ
    EA = 1;
    while(1){
        }
}

void et0_isr() interrupt 1{

    //reload timer setting
    //TIMER0_RELOAD(1000, 1);
    //clear int flag
    TIMER0_CLEAR_INTF();
}

void et1_isr() interrupt 3{
    P2 ^= 0x40 ;
    //reload timer setting
    TIMER1_RELOAD(250, 0);
    //clear int flag
    TIMER1_CLEAR_INTF();
    cntN++;
    if(cntN&0x07!=0)return;
    ///*
    txPktId++;
    Fifo_Data1[0]=txPktId&0xff;
    Fifo_Data1[1]=((txPktId>>8)&0xff);
    Fifo_Data1[2]+=10;
    P2 |= 0x80 ;
    curChn++;
    curChn&=3;
    StartRfTX(tblRfChn[curChn], Fifo_Data1, 12);
    while(1){
        if(TRX_IRQ_STATUS & B_IRQ_TX_DS){
            TRX_IRQ_STATUS = B_IRQ_TX_DS;
            break;
        }

        if(TRX_IRQ_STATUS & B_IRQ_MAX_RT){
            TRX_IRQ_STATUS = B_IRQ_MAX_RT;
            FLUSH_TX;
            break;
        }
    }
    RF_CE(0);
    P2 ^= 0x80 ;
    //*/
}


