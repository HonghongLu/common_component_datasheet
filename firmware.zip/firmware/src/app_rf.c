#include <stdio.h>
#include <string.h>

#include "bk2461.h"
#include "driver_gpio.h"
#include "driver_pwm.h"
#include "driver_saradc.h"

#include "driver_rf.h"

#define __RF_TEST__
#ifdef __RF_TEST__

xdata uint8  Fifo_Data[32];

void adc_init(uint8 chn){
     ADC_OPEN_CLOCK();
     //ADC_12bitSetup(3, 999, 2);
     ADC_10bitSetup(3, 999, chn);
     ADC_OPEN();
}

void pwm_init(){
    PWM_OPEN_CLOCK();
    PWM_SetupIOL(BIT(3))
	PWM_Setup(3, 63, 255, 100);
	PWM_Open(3);//*/
}
const uint8 tblRfChn[]={1,2,3,4};

void StartRfTX(uint8 chn,char*buf,uint8 len){
    RF_Set_Chn(chn);
    //delay(50);
    SwitchToTxMode();
    FLUSH_TX;
    FLUSH_RX;
    while(TRX_FIFO_STATUS & B_FIFO_TX_FULL);    // Wait for TX_FIFO empty
    W_TX_PAYLOAD(buf, len);
}

//uint8 SendBuf[10];
//uint8 rxBuf[10];
void test_rfTX (void)
{
    uint8 phase = 0;

 //   uint8 i;
    int cnt_dr = 0;
    int cnt_ds = 0;
    int cnt_rt = 0;
    int cnt_send = 0;
    uint8 current_pipe;
    uint8 cnt_loop_pipes = 0;
    uint8 SendBuf[5];
	uint8 Val = 0;
    uint8 chn=0;
    ChangeTxPipe(2);
    current_pipe = 2;
//    RF_Set_Chn(tblRfChn[0]);
//    SwitchToTxMode();
//    FLUSH_TX;
//    FLUSH_RX;
    //TRX_IRQ_STATUS = 0x70;
    RF_SetupInterrupt(B_IRQ_MAX_RT|B_IRQ_TX_DS|B_IRQ_RX_DR);
    memset(SendBuf,0,5);
	memcpy(Fifo_Data, SendBuf, 5);
	Fifo_Data[1] = current_pipe;

	do
	{

        //while(TRX_FIFO_STATUS & B_FIFO_TX_FULL);    // Wait for TX_FIFO empty
        //W_TX_PAYLOAD(Fifo_Data, 5);
        StartRfTX(tblRfChn[chn], Fifo_Data, 5);

        Delay_ms(4);
        while(1){
            if(TRX_IRQ_STATUS & B_IRQ_TX_DS)
            {
                PRINT("IRQ_TX_DS\n");
                TRX_IRQ_STATUS = B_IRQ_TX_DS;
                break;
            }

            if(TRX_IRQ_STATUS & B_IRQ_MAX_RT)
            {
                PRINT("IRQ_MAX_RT\n");
                TRX_IRQ_STATUS = B_IRQ_MAX_RT;
                FLUSH_TX;
                break;
            }
        }
        RF_CE(0);
//        chn++;
//        if(chn>3)chn=0;
        RF_Set_Chn(tblRfChn[chn]);
        //while(ADC_CHECK_RDY());
        SendBuf[0]++;

        //SendBuf[1]=(((ADC_DATAH&0x03)<<6)|((ADC_DATAL&0xfc)>>2));

        SendBuf[1]=phase;   // Send a triangle wave
        phase++;

        memcpy(Fifo_Data,SendBuf,5);
        PRINT("rf @%bd pkt id=%bx adc=%bx\r\n",tblRfChn[chn],SendBuf[0],SendBuf[1]);

        P27 = 1;
        Delay_ms(3);
        P27 = 0;

        //SwitchToTxMode();
        //Delay_ms(80);
	}while(1);

}


void led_EN()
{
    P30 = 1;
}

void led_DIS()
{
    P30 = 0;
}


void test_rfRX(void)
{
//    uint8 i;
    int cnt_dr = 0;
    uint8 current_pipe;
    uint8 bytes;
    uint8 chn=0;
    SwitchToRxMode ( );
    FLUSH_TX;
    FLUSH_RX;
    TRX_IRQ_STATUS = 0x70;
    //while(1);
    GPIO_OutputSetup(2,BIT(4), BIT(4), 0);
    do
    {
	//P27=0;
	while((TRX_IRQ_STATUS & B_IRQ_RX_DR)==0);
        //P27=1;
        bytes = TRX_RX_RPL_WIDTH;
        // read payload width for dynamic length
        current_pipe = ( TRX_IRQ_STATUS & 0x0E ) >> 1;
        R_RX_PAYLOAD(Fifo_Data, bytes);
        TRX_IRQ_STATUS = B_IRQ_RX_DR;
        //RF_CE(0);
//        chn++;
//        if(chn>3)chn=0;
        RF_Set_Chn(tblRfChn[chn]);
        SwitchToRxMode();
        PRINT("rf@%bd:rx pktid=%bx pwm duty=%bx\r\n",tblRfChn[chn],Fifo_Data[0],Fifo_Data[1]);

        // 1-bit output
        if(Fifo_Data[1] > 128)
            led_EN();
        else
            led_DIS();
//        PWM_SET_DUTY(3, Fifo_Data[1]);

    }while(1);
}

void test_rf(uint8 mode){
     switch(mode){
        case 0:
            PRINT("TX MODE\r\n");
            adc_init(4);
            RF_Init();
            test_rfTX();
            break;
        case 1:
            PRINT("RX MODE\r\n");
            pwm_init();
            RF_Init();
            test_rfRX();
            break;
        /*
        case 2:
            {
            PRINT("TX PN9 MODE\r\n");
            RF_Pn9TX(0);
            while(1){
                }
            }
	        break;
        case 3:
            {
                PRINT("BER test MODE\r\n");
                while(1){
                    RF_BerRX(0);
                    }
            }
            break;
        case 4:
            {
                uint8 rfchn=0;
			    RF_SingleWaveTest(rfchn, 0);
                while(1){
                    waitForKey();
                    rfchn+=5;
                    if(rfchn>79)rfchn=0;
                    RF_SingleWaveTest(rfchn, 0);
                    }
            }
            break;
        case 5:
            {
                TRX_CFG_0D_3 |= BIT(7);
                TRX_CFG_0D_3 &= (~(0x1f<<2));
                SwitchToTxMode();
                while(1){
                    PRINT("rssi=%bd\r\n",((TRX_RSSI_IND>>1)&0x1f));
                    Delay_ms(10);
                    }
            }
            break;
        //*/
        }
     PRINT("error\r\n");
     while(1);
}

#endif

